NAME:
=====
	Ariel M. Shultz

Programs Files:
===============
    Part 1:
        LinkedListInterface.java, LinkedListInterfaceComp.java, ReadCSV.java
    Part 2:
        Baby.java, SingleLinkedList.java
    Part 3:
        Main.java
	
How to Compile:
===============
    Part 1:
        javac LinkedListInterface.java, javac LinkedListInterfaceComp.java, javac ReadCSV.java
    Part 2:
        javac Baby.java, javac SingleLinkedList.java
    Part 3: 
        javac Main.java
       
How to Run:
===========
    (Unnecessary to run parts 1 & 2)
    Part 3 (example): java Main 2000 2001 2002

Known Bugs or Limitations:
==========================
    The runtime is okay; takes about a minute or two to run program. 